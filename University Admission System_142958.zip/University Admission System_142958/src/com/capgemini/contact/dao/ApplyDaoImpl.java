package com.capgemini.contact.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
//import org.apache.log4j.Logger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;
import com.capgemini.contact.util.DBUtil;

public class ApplyDaoImpl implements ApplyDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger universityLogger=null;

	public ApplyDaoImpl()
	{
		PropertyConfigurator.configure("resourses/log4j.properties");
		universityLogger=Logger.getLogger("ApplyDaoImpl.class");
	}
	/***********************Enter Applicant Details*************************************/
	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException
	{
		int dataAdded;
		String insertQry="INSERT INTO Candidate_Detail(applyId, firstName, lastName, contactNo, email, aggregate, stream) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			long getAppId=getApplyId();
			pst.setLong(1,getAppId );
			pst.setString(2, applicant.getfName());
			pst.setString(3, applicant.getlName());
			pst.setLong(4, applicant.getContactNo());
			pst.setString(5, applicant.getEmail());
			pst.setFloat(6, applicant.getAggregate());
			pst.setString(7, applicant.getStream());
			dataAdded=pst.executeUpdate();
			applicant.setApplyId(getAppId);
			universityLogger.log(Level.INFO, "Candidate Detail Inserted "+applicant);
		}
		catch (Exception e) 
		{
			universityLogger.error("This is Exception:"+e.getMessage());
			throw new ApplicantException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{

				throw new ApplicantException(e.getMessage());	
			}
		}
		return dataAdded;
	}
	/************************getApplyId()**********************************/
	@Override
	public long getApplyId() throws ApplicantException
	{
		int generatedId;
		String qry="SELECT apply_id_seq.NEXTVAL "
				+ " FROM DUAL";
		try 
		{
			con=DBUtil.getCon();
			System.out.println(con);
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedId=rs.getInt(1);

		} 
		catch (Exception e) 
		{
			throw new ApplicantException(e.getMessage());		
		} 
		finally				//reqd to closing all connections which are opened like con
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (SQLException e) 
			{	
				throw new ApplicantException(e.getMessage());		
			}

		}
		return generatedId;
	}
	/****************************View Applicant Details on Id****************************/
	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException 
	{
		String qry="SELECT * FROM Candidate_Detail  WHERE applyId =?";
		ApplicantBean applicant=null;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setLong(1, applicantID);
			rs=pst.executeQuery();
			rs.next();
			applicant= new ApplicantBean(rs.getLong("applyId"),rs.getString("firstName"),
					rs.getString("lastName"),rs.getLong("contactNo"), 
					rs.getString("email"), rs.getFloat("aggregate"), rs.getString("stream"));
			universityLogger.log(Level.INFO, "Applicant Detail on Id is Fetched "+applicant);
		}
		catch(Exception e)
		{
			universityLogger.error("This is Exception:"+e.getMessage());
			throw new ApplicantException(e.getMessage());
		}
		finally
		{
			try
			{
				con.close();
				pst.close();
				rs.close();
			}
			catch(Exception e)
			{
				universityLogger.error("This is Exception:"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		}
		return applicant;
	}

}
