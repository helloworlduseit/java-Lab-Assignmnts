package com.capgemini.contact.dao;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;

public interface ApplyDao 
{
	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException;
	public long getApplyId() throws ApplicantException;
	
	public ApplicantBean getApplicantDetails(long applicantID) throws ApplicantException;

}
