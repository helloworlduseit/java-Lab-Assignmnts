package com.capgemini.contact.service;

import java.util.regex.Pattern;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.dao.ApplyDao;
import com.capgemini.contact.dao.ApplyDaoImpl;
import com.capgemini.contact.exception.ApplicantException;



public class ApplyServiceimpl implements ApplyService
{
	ApplyDao applyDao=null;
	public ApplyServiceimpl()
	{
		applyDao= new ApplyDaoImpl();
	}
	/**************************addApplicantDetails*********************/
	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException 
	{		
		return applyDao.addApplicantDetails(applicant);
	}

	/*************************getApplicantDetails**************************/
	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException 
	{		
		return applyDao.getApplicantDetails(applicantID);
	}
	/**************************isValidApplicant******************************/
	@Override
	public boolean isValidApplicant(ApplicantBean applicant)
			throws ApplicantException 
	{
		int flag = 0;
		try
		{
			if( validateContactNo(applicant.getContactNo()))
			{
				if(validateFirstName(applicant.getfName()))
				{
					if(validateLastName(applicant.getlName()))
					{
						if(validateStream(applicant.getStream()))
						{
							if(validateEmail(applicant.getEmail()))
							{
								if(validateAggregate(applicant.getAggregate()))
								{
									flag=1;
								}
							}
						}
					}
				}

			}
			if(flag==1)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch (Exception e) 
		{

			throw new ApplicantException(e.getMessage());
		}

	}

	/************Contact Number Validation********************/
	public boolean validateContactNo(long contactNo) throws ApplicantException 
	{

		String numPattern="[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, new Long(contactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new ApplicantException("Please Entered Valid 10 digit Mobile Number(Should be "
					+ "Start with 7,8 or 9)");
		}

	}
	/************First Name Validation********************/
	public boolean validateFirstName(String fname) throws ApplicantException 
	{
		String numPattern="[a-zA-z]{2,}";
		if(Pattern.matches(numPattern,fname))
		{
			return true;
		}
		else{
			throw new ApplicantException("Please Valid entered First Name");
		}
	}

	/************Last Name Validation********************/
	public boolean validateLastName(String lname) throws ApplicantException 
	{
		String numPattern="[a-zA-z]{2,}";
		if(Pattern.matches(numPattern,lname))
		{
			return true;
		}
		else{
			throw new ApplicantException("Please Valid entered Last Name");
		}
	}
	/************Stream Name Validation********************/
	public boolean validateStream(String stream) throws ApplicantException 
	{
		String numPattern1="ComputerSc";
		String numPattern2="Informationtechnology";
		if(stream.equals(numPattern1)||stream.equals(numPattern2))
		{
			return true;
		}
		else{
			throw new ApplicantException("Please Valid entered Stream "
					+ "\n Stream should be either ComputerSc or Informationtechnology.");
		}
	}
	/************Email Validation********************/
	public boolean validateEmail(String email) throws ApplicantException
	{
		String numPattern="^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
		if(Pattern.matches(numPattern, email))
		{
			return true;
		}
		else
		{
			throw new ApplicantException("Email ID Invaid....Plz entered Email ID like jyoti@gamil.com");
		}
	}
	/************Aggregate Validation********************/
	public boolean validateAggregate(float agg)throws ApplicantException
	{
		if(agg>0)
		{
			return true;
		}
		else{
			throw new ApplicantException("Please enter Valid Aggregate");
		}
	}

}
