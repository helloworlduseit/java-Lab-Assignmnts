package com.capgemini.contact.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.dao.ApplyDaoImpl;
import com.capgemini.contact.exception.ApplicantException;


public class ApplySericeImplTest 
{
	static ApplicantBean apply=null;
	static ApplyDaoImpl appDao=null;
	@BeforeClass
	public static void beforeClass() throws ApplicantException
	{
		appDao=new ApplyDaoImpl();
		apply=new ApplicantBean(appDao.getApplyId(), "Jyoti", "Mane",981234, 
				"xyz@gmail.com", 89.6F, "Informationtechnology");
	}
	@Test
	public void testAddapplicant1() throws ApplicantException
	{
		Assert.assertEquals(1, appDao.addApplicantDetails(apply));
	}
	
	/*********test case for displying application Details based on ApplyId*************/
	@Test
	public void testAddapplicant2() throws ApplicantException
	{
		Assert.assertEquals(apply, appDao.getApplicantDetails(1004));
	
	}

}
