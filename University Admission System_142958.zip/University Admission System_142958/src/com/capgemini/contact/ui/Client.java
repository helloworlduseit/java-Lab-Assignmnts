package com.capgemini.contact.ui;

import java.util.Scanner;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.exception.ApplicantException;
import com.capgemini.contact.service.ApplyService;
import com.capgemini.contact.service.ApplyServiceimpl;


public class Client {
	static Scanner sc=null;
	static ApplyService appser=null;

	public static void main(String[] args) 
	{
		sc=new Scanner(System.in);
		appser= new ApplyServiceimpl();
		System.out.println("********************Admission System*********************");
		int choice=0;
		while(true)
		{
			System.out.println("Select an Operation\n"
					+ "1. Enter Details\n"
					+ "2. View details based on Applicant Id\n"
					+ "0. Exit");
			System.out.println("**********************************************");
			System.out.println("Please Enter a Choice: ");			
			choice=sc.nextInt();
			System.out.println("**********************************************");
			switch(choice)
			{
			case 2:
			{
				insertDetail();
				break;
			}
			case 1:
			{
				viewDetailsOnId();
				break;
			}
			default:
			{
				System.out.println("Thank you for applying !!");
				System.exit(0);
				break;
			}
			}
		}
	}

	public static void viewDetailsOnId() 
	{
		ApplicantBean applicant=null;
		try{
			System.out.println("Enter First Name: ");
			String fName=sc.next();
			System.out.println("Enter Last Name: ");
			String lName=sc.next();
			System.out.println("Enter Contact Number: ");
			long contactNo=sc.nextLong();
			System.out.println("Enter Email: ");
			String email=sc.next();
			System.out.println("Enter Stream: ");
			String stream=sc.next();
			System.out.println("Enter Aggregate in qualifying exam: ");
			float aggre=sc.nextFloat();
			applicant= new ApplicantBean();
			applicant.setfName(fName);
			applicant.setlName(lName);
			applicant.setContactNo(contactNo);
			applicant.setEmail(email);
			applicant.setStream(stream);
			applicant.setAggregate(aggre);
			if(appser.isValidApplicant(applicant)){
				int data=appser.addApplicantDetails(applicant);
				if(data!=0)
				{
					System.out.println("Thnak you "+applicant.getfName()+" "+applicant.getlName()+""
							+ " Your Unique Id is "+applicant.getApplyId()+" we will contact you shortly");
				}
				else
				{
					System.out.println("May be Some Exception occus while Adding Data");
				}
			}
		}
		catch (ApplicantException e)
		{
			e.printStackTrace();
		}


	}

	public static void insertDetail() 
	{
		int data;
		ApplicantBean applicant=null;
		System.out.println("Enter ApplyId : ");
		long id=sc.nextLong();
		try
		{
			applicant=appser.getApplicantDetails(id);
			System.out.println(applicant);

		}
		catch (ApplicantException e)
		{
			System.out.println("Please entered Valid Application Id..!!");
		}


	}

}


